

#define BASE 10000
int count = 5000;
int count_1 = 5000;
int count_2 = 5000;
void init(int big_number[],int k)
{
  big_number[0]=k;
  for(int i=1;i<count;i++)
  {
    big_number[i]=0;
  }
}



int big_mul(int big_number[],int k)
{
  int cp=0,mul=0;
  for(int i=count-1;i>=0;i--)
  {
    mul = big_number[i]*k + cp;
    big_number[i] = mul % BASE;
    cp = mul / BASE;
  }
  //(cp>0)?(return 1):(return 0);
}


void big_div(int big_number[],int k)
{
  int div=0,remainder=0;
  for(int i=0;i<count;i++)
  {
    div = big_number[i]+remainder*BASE;
    big_number[i] = div / k;
    remainder = div % k ;
  }
}


int big_add(int big_number_1[],int big_number_2[])
{
  int cp = 0, sum =0;
  for(int i=count-1;i>=0;i--)
  {
    sum = big_number_1[i]+big_number_2[i]+cp;
    big_number_1[i] = sum % BASE ;
    cp = sum / BASE;
  }
 // (cp > 0 )?(return 1):(return 0);
}

void big_printf(int number[])
{
  int k=0;
  for(int i = 0;i<count;i++)
    {
      printf("%04d",number[i]);
      printf(" ");
      if(k==15)
      {
         printf("\n");
         k=0;
      }
      else
         k++;
    }
    printf("\n");
}

