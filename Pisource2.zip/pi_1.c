#include <stdio.h>
#include "big_number.h"
int main()
{
 int pi[5000],mul_sum[5000],j=0;
 init(mul_sum,2000);
 init(pi,2000);
 for(int i=1;i<=300000;i++)
 {
 big_mul(mul_sum,i);
 big_div(mul_sum,2*i+1);
 while(1)
 {
 if(mul_sum[j]==0)
 j++;
 else
 break ;
 }

 big_add(pi,mul_sum);
if(j>=4998)
break;
 }
 big_printf(pi);
 //big_printf(mul_sum);
}
