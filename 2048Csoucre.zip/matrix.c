#include <stdio.h>
#include <stdlib.h>
#include "matrix.h"
#define ROWS 12
#define COLUMNS 12

int main()
{

    int matrix[12][12];
    int matrix_zero[ROWS * COLUMNS];
    for(int i=0 ; i <= ROWS - 1;i ++)
        for(int j = 0; j <= COLUMNS - 1; j ++)
            matrix[i][j] = 0 ;
while(1)
{
    int matrix_zero_number = 0;
    int matrix_rand_two = 0;
    for(int i=0 ; i <= ROWS - 1;i ++)
        for(int j = 0; j <= COLUMNS - 1; j ++)
            if ( matrix[i][j] == 0)
                {
                    matrix_zero[matrix_zero_number] = i * ROWS + j ;
                    matrix_zero_number ++ ;
                }

    if(matrix_zero_number == 0)
        {
            printf("game over\n");
            return 0 ;
        }
    else
        {
            int numrand;
            numrand = matrix_zero[rand() % (matrix_zero_number + 1)];
            matrix[numrand / ROWS ][numrand % COLUMNS] = 2 ;
        }
    
    int inmber = 0;
    scanf("%d",&inmber);
    switch (inmber)
    {
    case 1:
        matrix_up(matrix);
        break;
    case 2:
        matrix_down(matrix);
        break;
    case 3:
        matrix_left(matrix);
        break;
    case 4:
        matrix_right(matrix);
        break;
    default:
        break;
    }

    for(int i = 0; i<= ROWS -1 ;i++)
    {
        printf("%d || %d || %d || %d || %d || %d || %d || %d || %d || %d || %d || %d || \n",\
        matrix[i][0],matrix[i][1],matrix[i][2],matrix[i][3],matrix[i][4],matrix[i][5],\
        matrix[i][6],matrix[i][7],matrix[i][8],matrix[i][9],matrix[i][10],matrix[i][11]);
    }
}
}