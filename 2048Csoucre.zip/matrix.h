#define ROWS 12
#define COLUMNS 12


void matrix_down(int matrix_[ROWS][COLUMNS])
{
    for(int count=0; count <= ROWS;count++)
        for(int i = ROWS -1 ; i >= 1; i --)
        {
            for(int j = COLUMNS -1 ; j >=0 ;j --)
                if (matrix_[i][j] == matrix_[i-1][j]  || matrix_[i][j] == 0 )
                    {
                        matrix_[i][j] = matrix_[i][j] + matrix_[i-1][j];
                        matrix_[i-1][j] = 0;
                    }
        }
}

void matrix_up(int matrix_[ROWS][COLUMNS])
{
    for(int count=0; count <= ROWS;count++)
        for(int i = 1 ; i<=ROWS - 1 ; i ++)
            for(int j = COLUMNS -1 ; j >=0 ;j --)
                if (matrix_[i-1][j] == matrix_[i][j]  || matrix_[i-1][j] == 0 )
                    {
                        matrix_[i-1][j] = matrix_[i-1][j] + matrix_[i][j];
                        matrix_[i][j] = 0;
                    }
}

void matrix_left(int matrix_[ROWS][COLUMNS])
{
    for(int count=0; count <= COLUMNS;count++)
        for(int j = 1 ; j<=COLUMNS - 1 ; j++)
            for(int i = ROWS -1 ; i >=0 ;i --)
                if (matrix_[i][j-1] == matrix_[i][j]  || matrix_[i][j-1] == 0 )
                {
                    matrix_[i][j-1] = matrix_[i][j-1] + matrix_[i][j];
                    matrix_[i][j] = 0;
                }
}


void matrix_right(int matrix_[ROWS][COLUMNS])
{   
    for(int count=0; count <= COLUMNS;count++)
        for(int j = COLUMNS -1 ; j >= 1; j --)
            for(int i = ROWS -1 ; i >=0 ;i --)
                if (matrix_[i][j] == matrix_[i][j-1]  || matrix_[i][j] == 0 )
                    {
                        matrix_[i][j] = matrix_[i][j] + matrix_[i][j-1];
                        matrix_[i][j-1] = 0;
                    }
}
